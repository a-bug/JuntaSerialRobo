import rclpy

from std_msgs.msg import String
from std_msgs.msg import UInt8MultiArray

def main(args=None):
    rclpy.init(args=args)

    node = rclpy.create_node('listener')

    subscription = node.create_subscription(
        UInt8MultiArray, 'serial_read', lambda msg: node.get_logger().info('I heard: "%s"' % msg.data), 10)
    subscription  # prevent unused variable warning

    rclpy.spin(node)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
