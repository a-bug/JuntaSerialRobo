import rclpy
from rclpy.node import Node

from std_msgs.msg import String
from std_msgs.msg import UInt8MultiArray


class Talker(Node):

    def __init__(self):
        super().__init__('talker')
        self.publisher_ = self.create_publisher(UInt8MultiArray, 'serial_write', 10)
        timer_period = 0.5  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.i = 0

    def timer_callback(self):
        msg = UInt8MultiArray()
        #msg.data = [66, 82, 13]
        if self.i%2 == 0:
            msg.data = [67, 74, 13]
        else:
            msg.data = [83, 74, 13]
        self.publisher_.publish(msg)
        self.i += 1


def main(args=None):
    rclpy.init(args=args)

    talker = Talker()

    rclpy.spin(talker)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    talker.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
